import discord
from discord.ext import commands
import random
import os

bot = commands.Bot(command_prefix='.')
db = {}
with open('database.json', 'r') as f:
  db = json.load(f)

@bot.event
async def on_ready():
  print(f'{bot.user.name} has connected to Discord!')

@bot.command(name='genbot', help='Generates a new bot with a custom message')
async def genbot(ctx, *, message):
  new_bot_token = 'your-new-bot-token-here'
  new_bot = commands.Bot(command_prefix='.')

  @new_bot.command(name='ltc', help='Returns the custom message')
  async def ltc(ctx):
    await ctx.send(message)

  @new_bot.event
  async def on_ready():
    print(f'{new_bot.user.name} has connected to Discord!')

  new_bot.run(new_bot_token)

bot.run(os.getenv('MTIzNzkxMzk5NDc0NTA4NTk4Mg.GjHprR.waqeUFatKcIOq05g3Y7NC9-cAeJHRNWA01jzWI'))